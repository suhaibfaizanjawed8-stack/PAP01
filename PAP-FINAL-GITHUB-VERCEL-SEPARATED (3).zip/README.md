# Prince Art Packages — Final GitHub / Vercel Package

This is a pure static HTML/CSS/JavaScript website. No npm install and no build step are required.
The existing website design, pages, images, fonts, CSS and JavaScript are kept in the repository root.

## Upload to GitHub
1. Extract the ZIP.
2. Open the extracted folder.
3. Upload ALL files and folders inside it to the ROOT of your GitHub repository.
4. On GitHub, `index.html` and `vercel.json` must be visible at the top level.
5. Do not upload the ZIP itself as the website.

## Vercel
Import the GitHub repository into Vercel and deploy it.
The included `vercel.json` forces:
- Framework: Other
- No build command
- No install command
- Output directory: repository root (`.`)

If the Vercel project was previously configured differently, redeploy the newest GitHub commit after uploading this package.
